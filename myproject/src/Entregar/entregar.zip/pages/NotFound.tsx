

function NotFound() {
    return (
        <div>PARECE QUE ESSA PÁGINA NÃO EXISTE!!!</div>
    )
}

export default NotFound